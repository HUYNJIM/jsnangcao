# Bankist

Bankist is one of the projects done as part of the course - [The Complete JavaScript Course 2021: From Zero to Expert!](https://www.udemy.com/course/the-complete-javascript-course/) by Jonas Schmedtmann.

## Features

* Modal windows

* Smooth scrolling

* Tab functionality

* Navigation fade animations

* Sticky navigation

* Revealing sections on scroll

* Lazy images loading

* Slider functionality
